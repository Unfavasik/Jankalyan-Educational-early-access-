
import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyB8oXr56Ec4D0EkOhQn1Wqdpjzz0_xO_VQ",
  authDomain: "jankalyan-education.firebaseapp.com",
  databaseURL: "https://jankalyan-education-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "jankalyan-education",
  storageBucket: "jankalyan-education.firebasestorage.app",
  messagingSenderId: "97400349382",
  appId: "1:97400349382:web:eda77227881cf75f95edc7",
  measurementId: "G-95C4Q14KXN"
};

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Initialize Database with explicit URL to ensure correct routing
const db = getDatabase(app, firebaseConfig.databaseURL);

// Initialize Analytics if supported in environment
if (typeof window !== "undefined") {
  getAnalytics(app);
}

export { db };
