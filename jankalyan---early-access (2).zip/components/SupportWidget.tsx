
import React, { useState, useEffect } from 'react';

interface SupportWidgetProps {
  isVisible?: boolean;
}

export const SupportWidget: React.FC<SupportWidgetProps> = ({ isVisible = true }) => {
  const [isOpen, setIsOpen] = useState(false);

  // Close the panel automatically if the widget is hidden
  useEffect(() => {
    if (!isVisible) setIsOpen(false);
  }, [isVisible]);

  return (
    <div className={`fixed bottom-10 right-8 z-[100] flex flex-col items-end transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] ${
      isVisible ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-12 scale-90 pointer-events-none'
    }`}>
      {/* Options Panel */}
      <div 
        className={`mb-6 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] ${
          isOpen 
            ? 'opacity-100 translate-y-0 scale-100' 
            : 'opacity-0 translate-y-8 scale-90 pointer-events-none'
        }`}
      >
        <div className="bg-[#020617]/90 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] p-5 shadow-[0_30px_100px_rgba(0,0,0,0.8)] ring-1 ring-white/10 space-y-3 w-72 overflow-hidden">
          <div className="px-3 py-2 border-b border-white/5 pb-4 mb-2">
            <h4 className="text-[10px] uppercase tracking-[0.5em] font-black text-indigo-400 mb-1">Direct Help</h4>
            <p className="text-[11px] text-slate-500 leading-tight">Secure lines open for immediate inquiry.</p>
          </div>
          
          <a 
            href="tel:+919091245366"
            className="flex items-center justify-between px-5 py-5 bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 rounded-2xl transition-all duration-500 group"
          >
            <div className="flex flex-col">
              <span className="text-[9px] uppercase tracking-[0.2em] text-slate-500 font-bold group-hover:text-white">Primary Support</span>
              <span className="text-sm font-bold text-white tracking-widest">+91 9091245366</span>
            </div>
            <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-white group-hover:text-slate-950 transition-all duration-500">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
            </div>
          </a>

          <a 
            href="tel:+919475361366"
            className="flex items-center justify-between px-5 py-5 bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 rounded-2xl transition-all duration-500 group"
          >
            <div className="flex flex-col">
              <span className="text-[9px] uppercase tracking-[0.2em] text-slate-500 font-bold group-hover:text-white">Alternate Support</span>
              <span className="text-sm font-bold text-white tracking-widest">+91 9475361366</span>
            </div>
            <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-white group-hover:text-slate-950 transition-all duration-500">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
            </div>
          </a>
        </div>
      </div>

      {/* Main Trigger */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`group relative flex items-center justify-center w-20 h-20 rounded-[2rem] shadow-[0_20px_50px_rgba(79,70,229,0.4)] transition-all duration-700 active:scale-90 ${
          isOpen ? 'bg-white text-slate-950 rotate-[225deg]' : 'bg-indigo-600 text-white'
        }`}
      >
        <div className="absolute inset-[-4px] rounded-[2.2rem] border border-indigo-500/20 animate-pulse pointer-events-none" />
        
        {isOpen ? (
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
        ) : (
          <div className="flex flex-col items-center justify-center -space-y-0.5">
            <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 12.02l-3.536-3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span className="text-[9px] font-black uppercase tracking-tight">Support</span>
          </div>
        )}
      </button>
    </div>
  );
};
