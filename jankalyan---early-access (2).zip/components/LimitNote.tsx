
import React from 'react';

export const LimitNote: React.FC = () => {
  return (
    <div className="reveal-on-scroll w-full max-w-md mx-auto text-center space-y-6" style={{ transitionDelay: '300ms' }}>
      <div className="inline-flex items-center px-5 py-2 rounded-full bg-amber-500/[0.05] border border-amber-500/20 text-amber-500 text-[10px] font-bold uppercase tracking-[0.25em] backdrop-blur-sm">
        <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mr-3 animate-pulse shadow-[0_0_10px_rgba(245,158,11,0.8)]" />
        Strictly Limited
      </div>
      <div className="space-y-2">
        <p className="text-slate-200 text-base font-light tracking-wide">
          Early Access is limited <span className="mx-2 text-slate-700">|</span> First come, first access
        </p>
        <p className="text-slate-500 text-[11px] font-semibold tracking-[0.2em] uppercase">
          Once closed, it won’t open again
        </p>
      </div>
    </div>
  );
};
