
import React from 'react';

export const InstitutionalFooter: React.FC = () => {
  return (
    <footer className="relative z-10 w-full border-t border-slate-800/50 pt-20 pb-12 mt-auto reveal-on-scroll">
      <div className="max-w-6xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-12 text-slate-500">
        
        {/* Contact Column */}
        <div className="space-y-4">
          <h4 className="text-[10px] uppercase tracking-[0.2em] font-bold text-slate-400">Direct Contact</h4>
          <div className="space-y-2 text-sm">
            <p className="flex items-center space-x-3">
              <span className="text-indigo-500 font-bold">+91</span>
              <span>9091245366 / 9475361366</span>
            </p>
          </div>
        </div>

        {/* Location Column */}
        <div className="space-y-4">
          <h4 className="text-[10px] uppercase tracking-[0.2em] font-bold text-slate-400">Head Office</h4>
          <p className="text-sm leading-relaxed">
            Kadbeltala, Panchanan Tala, Berhampore,<br />
            Murshidabad, West Bengal, India
          </p>
        </div>

        {/* Credentials Column */}
        <div className="space-y-4">
          <h4 className="text-[10px] uppercase tracking-[0.2em] font-bold text-slate-400">Affiliation & Trust</h4>
          <div className="space-y-1 text-[11px] leading-tight opacity-70">
            <p>MSME Registered | ISO No. - 9001 : 2015</p>
            <p>80G & 12A Certified</p>
            <p className="text-indigo-400/80 font-semibold uppercase tracking-widest pt-2">Run by JEIW Foundation</p>
          </div>
        </div>
      </div>

      <div className="mt-20 text-center opacity-40">
        <p className="text-[9px] uppercase tracking-[0.5em]">
          &copy; {new Date().getFullYear()} Jankalyan Educational Institution
        </p>
      </div>
    </footer>
  );
};
