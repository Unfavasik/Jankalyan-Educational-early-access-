
// This component has been replaced by the interactive floating SupportWidget.
export const ContactSection = () => null;
