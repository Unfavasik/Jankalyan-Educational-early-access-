
import React from 'react';

const features = [
  { title: "Elite Access Portal", desc: "Priority entry to our proprietary learning infrastructure." },
  { title: "Restricted Benefits", desc: "Tier-1 academic resources unavailable to the public." },
  { title: "Encrypted Features", desc: "Private consultation channels for career-defining moves." },
  { title: "The Great Unknown", desc: "Curated experiences that transcend traditional education." }
];

export const FeatureList: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full">
      {features.map((f, index) => (
        <div 
          key={index} 
          className="glass-v3 p-10 rounded-[2.5rem] hover:bg-white/[0.04] transition-all duration-700 group cursor-default border-white/5 hover:border-white/10"
        >
          <div className="flex flex-col h-full justify-between space-y-12">
            <div className="flex justify-between items-center">
              <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center text-[11px] font-black text-slate-500 group-hover:bg-indigo-500 group-hover:text-white transition-all duration-700 group-hover:scale-110">
                0{index + 1}
              </div>
              <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-700">
                <svg className="w-6 h-6 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="text-2xl md:text-3xl font-black tracking-tight text-white/90 group-hover:text-white">
                {f.title}
              </h3>
              <p className="text-slate-500 text-sm font-light leading-relaxed group-hover:text-slate-400 transition-colors">
                {f.desc}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
