
import React from 'react';

const benefitsList = [
  "Early access to our platform",
  "Special course benefits (limited)",
  "Hidden features unlocked",
  "Something mysterious waiting for you"
];

const CheckIcon = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-indigo-400">
    <path d="M20 6L9 17L4 12" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const Benefits: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-xl mx-auto w-full px-4">
      {benefitsList.map((benefit, index) => (
        <div 
          key={index} 
          className="flex items-center space-x-3 p-4 bg-white/[0.02] border border-white/5 rounded-2xl hover:bg-white/[0.05] transition-all duration-300"
        >
          <div className="flex-shrink-0 w-5 h-5 flex items-center justify-center rounded-full bg-indigo-500/10 border border-indigo-500/20">
            <CheckIcon />
          </div>
          <span className="text-slate-300 font-medium text-[13px] tracking-tight">
            {benefit}
          </span>
        </div>
      ))}
    </div>
  );
};
