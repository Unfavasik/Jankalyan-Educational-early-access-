
import React, { useState, useCallback } from 'react';
import { db } from '../firebase';
import { ref, push, set, runTransaction, get } from "firebase/database";

interface AccessFormProps {
  onSuccess: () => void;
  onFocusChange?: (focused: boolean) => void;
}

export const AccessForm: React.FC<AccessFormProps> = ({ onSuccess, onFocusChange }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({ name: '', email: '', phone: '' });

  const handleFocus = () => onFocusChange?.(true);
  const handleBlur = () => {
    setTimeout(() => {
      if (!document.activeElement?.closest('form')) {
        onFocusChange?.(false);
      }
    }, 50);
  };

  // Helper to make strings safe for Firebase Keys
  const sanitizeKey = (str: string) => str.toLowerCase().replace(/[.#$[\]]/g, "_");
  
  // Normalize phone to catch any edge cases, though input is now limited
  const normalizePhone = (str: string) => {
    const digits = str.replace(/\D/g, "");
    return digits.length >= 10 ? digits.slice(-10) : digits;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, ""); // Remove non-digits
    if (val.length <= 10) {
      setFormData(p => ({ ...p, phone: val }));
    }
  };

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;

    setLoading(true);
    setError('');

    const email = formData.email.toLowerCase().trim();
    const phone = formData.phone.trim();
    const emailKey = sanitizeKey(email);

    try {
      if (!formData.name.trim() || !email || !phone) {
        setError('All credentials required.');
        setLoading(false);
        return;
      }

      if (phone.length !== 10) {
        setError('Mobile number must be exactly 10 digits.');
        setLoading(false);
        return;
      }

      // 1. Strict Device-Level Check
      const usedEmails = JSON.parse(localStorage.getItem('used_emails') || '[]');
      const usedPhones = JSON.parse(localStorage.getItem('used_phones') || '[]');

      if (usedEmails.includes(email) || usedPhones.includes(phone)) {
        setError('Access already granted to this identity.');
        setLoading(false);
        return;
      }

      // 2. Global Database Check
      const emailLookupRef = ref(db, `lookups/emails/${emailKey}`);
      const phoneLookupRef = ref(db, `lookups/phones/${phone}`);

      const [emailSnap, phoneSnap] = await Promise.all([
        get(emailLookupRef),
        get(phoneLookupRef)
      ]);

      if (emailSnap.exists()) {
        setError('Email protocol already active.');
        setLoading(false);
        return;
      }

      if (phoneSnap.exists()) {
        setError('Mobile number already registered.');
        setLoading(false);
        return;
      }

      // 3. Atomic Capacity Update
      const spotsRef = ref(db, 'stats/spots_left');
      const spotResult = await runTransaction(spotsRef, (current) => {
        if (current === null) return 499999;
        if (current <= 0) return 0;
        return current - 1;
      });

      if (!spotResult.committed) throw new Error('Network congestion.');

      // 4. Secure Identity Registration
      const registrationsRef = ref(db, 'registrations');
      const newRegRef = push(registrationsRef);
      const timestamp = Date.now();
      
      await Promise.all([
        set(newRegRef, {
          name: formData.name.trim(),
          email: email,
          phone: phone,
          timestamp: timestamp,
          source: 'elite_portal_v3_secure'
        }),
        set(emailLookupRef, { active: true, registeredAt: timestamp }),
        set(phoneLookupRef, { active: true, registeredAt: timestamp })
      ]);

      // 5. Hard Lock locally
      usedEmails.push(email);
      usedPhones.push(phone);
      localStorage.setItem('used_emails', JSON.stringify(usedEmails));
      localStorage.setItem('used_phones', JSON.stringify(usedPhones));
      
      setLoading(false);
      onSuccess();

    } catch (err: any) {
      console.error("Auth Fail:", err);
      setError('Connection interrupted. Try again.');
      setLoading(false);
    }
  }, [formData, loading, onSuccess]);

  const inputStyles = `
    w-full bg-white/[0.03] border border-white/10 rounded-2xl py-5 px-7 
    text-white placeholder-slate-700 text-base
    focus:outline-none focus:ring-1 focus:ring-indigo-500/50 focus:bg-white/[0.06]
    transition-all duration-500 font-light tracking-wide
  `;

  return (
    <form onSubmit={handleSubmit} className="space-y-10" onFocus={handleFocus} onBlur={handleBlur}>
      <div className="space-y-7">
        <div className="group">
          <label className="block text-[9px] text-slate-500 ml-1 mb-3 uppercase tracking-[0.4em] font-black group-focus-within:text-indigo-400 transition-colors">
            Legal Identity
          </label>
          <input
            type="text"
            required
            placeholder="Your Full Name"
            className={inputStyles}
            value={formData.name}
            onChange={(e) => setFormData(p => ({ ...p, name: e.target.value }))}
          />
        </div>

        <div className="group">
          <label className="block text-[9px] text-slate-500 ml-1 mb-3 uppercase tracking-[0.4em] font-black group-focus-within:text-indigo-400 transition-colors">
            Gmail Secure Point
          </label>
          <input
            type="email"
            required
            placeholder="example@gmail.com"
            className={inputStyles}
            value={formData.email}
            onChange={(e) => setFormData(p => ({ ...p, email: e.target.value }))}
          />
        </div>

        <div className="group">
          <div className="flex justify-between items-center mb-3">
            <label className="block text-[9px] text-slate-500 ml-1 uppercase tracking-[0.4em] font-black group-focus-within:text-indigo-400 transition-colors">
              Contact Number
            </label>
            <span className="text-[9px] text-slate-600 font-bold tabular-nums">
              {formData.phone.length}/10
            </span>
          </div>
          <input
            type="tel"
            required
            maxLength={10}
            placeholder="10 digit mobile"
            className={inputStyles}
            value={formData.phone}
            onChange={handlePhoneChange}
          />
        </div>
      </div>

      {error && (
        <div className="text-red-400 text-[10px] font-black text-center tracking-[0.2em] uppercase py-4 border border-red-500/20 rounded-2xl bg-red-500/5 animate-pulse">
          {error}
        </div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="shimmer-v2 w-full bg-white text-slate-950 font-black py-6 rounded-2xl hover:scale-[1.01] transition-all duration-700 active:scale-[0.99] disabled:opacity-50 text-[12px] uppercase tracking-[0.5em] shadow-2xl"
      >
        <span className="flex items-center justify-center space-x-3">
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              <span>Checking Protocol...</span>
            </>
          ) : 'Initiate Request'}
        </span>
      </button>
    </form>
  );
};
