
import React, { useState, useEffect, useCallback } from 'react';
import { AccessForm } from './components/AccessForm';
import { FeatureList } from './components/FeatureList';
import { Benefits } from './components/Benefits';
import { LimitNote } from './components/LimitNote';
import { InstitutionalFooter } from './components/InstitutionalFooter';
import { ShareButtons } from './components/ShareButtons';
import { SupportWidget } from './components/SupportWidget';
import { db } from './firebase';
import { ref, onValue, runTransaction, get } from "firebase/database";

const INITIAL_SPOTS = 500000;
const BACKGROUND_DECREMENT = 5;
const DECREMENT_INTERVAL_MS = 20 * 60 * 1000; // 20 minutes

const App: React.FC = () => {
  const [isJoined, setIsJoined] = useState(false);
  const [isFormFocused, setIsFormFocused] = useState(false);
  const [spotsLeft, setSpotsLeft] = useState(INITIAL_SPOTS);

  useEffect(() => {
    // 1. Setup Intersection Observer for animations
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) entry.target.classList.add('active');
      });
    }, { threshold: 0.15 });

    document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));

    // 2. Listen to Real-time Spots from Firebase
    const spotsRef = ref(db, 'stats/spots_left');
    const unsubscribe = onValue(spotsRef, (snapshot) => {
      const val = snapshot.val();
      if (val !== null) {
        setSpotsLeft(val);
      } else {
        // Initialize if not exists
        runTransaction(spotsRef, (current) => current === null ? INITIAL_SPOTS : current);
      }
    });

    // 3. Background Decrement Logic (5 spots every 20 mins)
    const checkBackgroundDecrement = async () => {
      const lastUpdateRef = ref(db, 'stats/last_background_decrement');
      const snapshot = await get(lastUpdateRef);
      const lastUpdate = snapshot.val() || 0;
      const now = Date.now();

      if (now - lastUpdate >= DECREMENT_INTERVAL_MS) {
        // Time to decrement
        await runTransaction(spotsRef, (current) => {
          if (current === null) return INITIAL_SPOTS - BACKGROUND_DECREMENT;
          return Math.max(10, current - BACKGROUND_DECREMENT);
        });
        // Update the timestamp so other clients don't do it immediately
        await runTransaction(lastUpdateRef, () => now);
      }
    };

    const bgInterval = setInterval(checkBackgroundDecrement, 60000); // Check every minute
    checkBackgroundDecrement();

    return () => {
      observer.disconnect();
      unsubscribe();
      clearInterval(bgInterval);
    };
  }, []);

  const handleJoinSuccess = useCallback(() => {
    // Show success message
    setIsJoined(true);
    setIsFormFocused(false);
    
    // Smooth scroll to the success message
    setTimeout(() => {
      document.getElementById('access-zone')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);

    // CLOSE after 5 seconds as per user request
    setTimeout(() => {
      setIsJoined(false);
    }, 5000);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center px-6 pt-24 pb-12 relative selection:bg-indigo-500/30">
      <main className="relative z-10 w-full max-w-5xl flex flex-col items-center">
        
        {/* Spot Counter - Global Sync */}
        <div className="reveal mb-16">
          <div className="glass-v3 px-5 py-2 rounded-full flex items-center space-x-3 border-indigo-500/20">
             <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,1)] animate-pulse" />
             <span className="text-[9px] font-black uppercase tracking-[0.4em] text-indigo-300">
               {spotsLeft.toLocaleString()} Limited Spots Available
             </span>
          </div>
        </div>

        {/* Cinematic Hero */}
        <header className="space-y-10 mb-36 text-center reveal">
          <div className="space-y-2">
            <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.7em] opacity-60">
              Future of Learning
            </p>
            <h1 className="text-6xl md:text-9xl font-black tracking-tighter leading-[0.85] text-white">
              Elite Access <br />
              <span className="bg-gradient-to-r from-indigo-300 via-white to-slate-400 bg-clip-text text-transparent italic font-light">Now Active</span>
            </h1>
          </div>
          <p className="text-slate-400 text-lg md:text-xl font-light tracking-wide max-w-xl mx-auto leading-relaxed">
            Reserved for those who seek the <span className="text-white border-b border-indigo-500/30">extraordinary.</span> Join the inner circle of Jankalyan.
          </p>
        </header>

        <div className="w-full space-y-48 mb-48">
          <div className="reveal">
            <FeatureList />
          </div>
          
          <div className="reveal max-w-2xl mx-auto w-full">
             <div className="flex flex-col items-center space-y-12">
               <div className="text-center space-y-2">
                 <h2 className="text-[10px] uppercase tracking-[0.6em] text-indigo-400 font-black">Membership Benefits</h2>
                 <p className="text-slate-500 text-sm font-light">Exclusive protocols enabled for early members</p>
               </div>
               <Benefits />
             </div>
          </div>

          <div className="reveal">
            <LimitNote />
          </div>
        </div>

        <div id="access-zone" className="w-full max-w-lg reveal mb-40">
          {isJoined ? (
            <div className="glass-v3 p-16 md:p-20 rounded-[4rem] text-center space-y-12 animate-in fade-in zoom-in duration-1000 border-indigo-500/30">
              <div className="relative inline-block group">
                <div className="absolute inset-0 bg-indigo-500 blur-3xl opacity-20 group-hover:opacity-40 transition-opacity"></div>
                <div className="relative h-32 w-32 bg-white rounded-[3rem] flex items-center justify-center mx-auto shadow-2xl transition-transform group-hover:scale-110">
                  <svg className="w-16 h-16 text-slate-950" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-5xl font-black tracking-tighter text-white">You're In.</h3>
                <p className="text-slate-400 font-light text-lg leading-relaxed px-4">
                  Registration successful. Monitoring protocols initiated. Check your <span className="text-white font-semibold">Gmail</span>.
                </p>
              </div>
              <div className="pt-12 border-t border-white/5">
                <ShareButtons />
              </div>
            </div>
          ) : (
            <div className={`glass-v3 p-2 rounded-[3.5rem] transition-all duration-700 ${isFormFocused ? 'border-indigo-500/40 shadow-[0_0_50px_rgba(99,102,241,0.1)]' : 'hover:border-indigo-500/20'}`}>
              <div className="bg-slate-950/40 rounded-[3.2rem] p-10 md:p-14">
                <AccessForm 
                  onSuccess={handleJoinSuccess} 
                  onFocusChange={setIsFormFocused}
                />
              </div>
            </div>
          )}
        </div>

        <div className="mt-32 text-center reveal opacity-40 hover:opacity-100 transition-opacity duration-1000">
           <div className="w-px h-16 bg-gradient-to-b from-indigo-500 to-transparent mx-auto mb-8" />
           <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.8em]">
             End of Protocol
           </p>
        </div>
      </main>

      <SupportWidget isVisible={!isFormFocused} />
      <InstitutionalFooter />
    </div>
  );
};

export default App;
